INSERT into params (name,value,descr) VALUES ('clamavadm','','Adresse mail pour clamav');
INSERT into params (name,value,descr) VALUES ('clamavmail','0','Mailing pour clamav');